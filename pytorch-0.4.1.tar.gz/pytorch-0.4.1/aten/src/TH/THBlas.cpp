#include "THBlas.h"

#include "generic/THBlas.cpp"
#include "THGenerateAllTypes.h"
