#include "THCTensorCopy.h"
#include "THCTensor.hpp"
#include "THCStream.h"
#include "THCCachingHostAllocator.h"

#include "generic/THCTensorCopy.cpp"
#include "THCGenerateAllTypes.h"
