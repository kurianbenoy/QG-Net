#include "THCStorageCopy.h"
#include "THCTensor.hpp"

#include "THCTensorCopy.h"

#include "generic/THCStorageCopy.cpp"
#include "THCGenerateAllTypes.h"
